# Faculty of Information and Communication Technology <br/> ITDS242 Web Technologies Lab <br/> Node.js

## คำชี้แจง
- แบบฝึกปฏิบัตินี้มีทั้งหมด 1 ข้อ ที่เกี่ยวกับการสร้าง server และการทำ routing ด้วย Express Framework ใน Node.js 
- การส่งงานขอให้นักศึกษาส่งงานผ่าน GitHub ภายในเวลาที่กำหนด

---

## ขั้นตอนการเตรียมโปรเจค Express
1. ตรวจสอบว่า เครื่องคอมพิวเตอร์ได้ลง Node.js เรียบร้อยแล้ว โดยสามารถใช้คำสั่ง `node --version` ใน terminal
2. สร้างโฟลเดอร์สำหรับงาน โดยตั้งชื่อว่า `XX87XXX-express`
3. เปิด Visual Studio Code และ Open Folder ไปที่โฟลเดอร์ที่สร้างไว้ในข้อที่ 2
4. เปิด terminal ใน Visual Studio Code เพื่อทำการ initialize และ set up โปรเจค โดยใช้คำสั่ง `npm init`
5. ใส่ข้อมูลโปรเจค โดยตั้ง entry point เป็นไฟล์ ชื่อ `app.js` และใส่ชื่อ-นามสกุล และรหัสนักศึกษา ในส่วนของ `author` (ข้อมูลส่วนอื่น ๆ สามารถข้ามได้)
   เสร็จแล้วให้พิมพ์ "yes" เพื่อยืนยัน
   
   หลังจากขั้นตอนนี้ โครงสร้างของโฟลเดอร์จะเป็น

   ```
   XX87XXX-express		(root)
	|_ package.json
   ```

   และในไฟล์ `package.json` ควรมีข้อมูล ดังตัวอย่าง
   ```
	{
	  "name": "XX87XXX-express",
	  "version": "1.0.0",
	  "description": "",
	  "main": "app.js",
	  "scripts": {
	    "test": "echo \"Error: no test specified\" && exit 1"
	  },
	  "author": "[Your Name], [Your Student ID]",
	  "license": "ISC"
	}
   ```

6. สร้างไฟล์หลัก (entry point) ชื่อว่า `app.js` ซึ่งจะเป็นไฟล์หลักของ server
   หลังจากขั้นตอนนี้ โครงสร้างของโฟลเดอร์จะเป็น

   ```
   XX87XXX-express		(root)
	|_ app.js		(entry point file)
    |_ package.json	
   ```
7. ลง module `express` โดยใช้คำสั่ง `npm install express` **และ**
   ลง module `nodemon` โดยใช้คำสั่ง `npm install nodemon`
   
   หลังจากขั้นตอนนี้ โครงสร้างของโฟลเดอร์จะเป็น
   ```
   XX87XXX-express		(root)
	> node_modules		(folder)
 	|_ app.js		(top-level)
    |_ package_lock.json	(top-level)
    |_ package.json	(top-level)
   
   ```
   
   และในไฟล์ `package.json` ควรมี `dependencies` เพิ่มเองโดยอัตโนมัติ เป็น
   ```
	{
	  "name": "XX87XXX-express",
	  "version": "1.0.0",
	  "description": "",
	  "main": "app.js",
	  "scripts": {
	    "test": "echo \"Error: no test specified\" && exit 1"
	  },
	  "author": "[Your Name], [Your Student ID]",
	  "license": "ISC",
	  "dependencies": {
   		"express": "^5.3.0",
   		"nodemon": "^3.1.14"
  	  }
	}
   ```
8. ตั้งค่าคำสั่ง  start ใน  `package.json` โดยพิมพ์คำสั่ง `"start": "nodemon app.js"` แทนคำสั่งเดิมในส่วน `"scripts"`
  
   หลังจากขั้นตอนนี้ ไฟล์ `package.json` ควรมีค่าในส่วน `scripts` เป็น
   ```
	{
	  "name": "XX87XXX-express",
	  "version": "1.0.0",
	  "description": "",
	  "main": "app.js",
	  "scripts": {
	    "start": "nodemon app.js"
	  },
	  "author": "[Your Name], [Your Student ID]",
	  "license": "ISC",
	  "dependencies": {
   		"express": "^5.3.0",
   		"nodemon": "^3.1.14"
  	  }
	}
   ```
9. ดาวน์โหลด ไฟล์ html ทั้งหมด และวางในโฟลเดอร์โปรเจคในโฟลเดอร์ชื่อ `html` ดังนี้
   
   ```
   XX87XXX-express		(root)
    > html			(folder)
	   |_ error.html		(inside html folder)
	   |_ sign-in.html		(inside html folder)
	   |_ error.html		(inside html folder)

    > node_modules		(folder)
    |_ app.js		(top level)
    |_ package_lock.json	(top level)
    |_ package.json	(top level)
   
   ```
---

## โจทย์

**จงเขียนชุดคำสั่งเพื่อสร้าง server ด้วย Express Framework** ทั้งนี้ server จะมีการ Routing และการทำงานต่าง ๆ ดังนี้

* Server จะทำงานที่ `localhost` และ `port=3030` ([**ตัวอย่างผลลัพธ์ที่ 1**](#ตัวอย่างผลลัพธ์ที่-1))
  
* Request: `GET	http://localhost:3030/` ([**ตัวอย่างผลลัพธ์ที่ 2**](#ตัวอย่างผลลัพธ์ที่-2))<br>เป็น route ที่ผู้ใช้จะได้รับ response จะเป็นข้อความ  "Hello World! in plain text"
  และมีการ log ใน terminal
  
* Request: `GET	http://localhost:3030/signin` ([**ตัวอย่างผลลัพธ์ที่ 3**](#ตัวอย่างผลลัพธ์ที่-3))<br>เป็น route ที่ผู้ใช้จะได้รับ response จะเป็นหน้า `sign-in.html` 
  และมีการ log ใน terminal
  
* ในหน้า `sign-in.html` จะต้องตั้งค่าการ `submit` ของ form เป็น method `POST` **และ** ถูกส่งไปที่ route `/form-submit`
  
* Request: `POST	http://localhost:3030/form-submit` ([**ตัวอย่างผลลัพธ์ที่ 4**](#ตัวอย่างผลลัพธ์ที่-4))<br>เป็น route สำหรับ form handling ซึ่ง server จะไม่ได้ส่ง response ใด ๆ กลับไป
  **แต่** จะ log ใน terminal ด้วยข้อมูลอีเมลและเวลา timestamp ที่ form ถูก submit จากนั้น `redirect` ไปยัง route `/member` 
  <br>**Hint** `res.redirect('/path')` เป็นการเปลี่ยน path ไปยัง url ที่กำหนด
  
* Request: `GET	http://localhost:3030/member` ([**ตัวอย่างผลลัพธ์ที่ 5**](#ตัวอย่างผลลัพธ์ที่-5))<br>เป็น route สำหรับการแสดงผลหลังผู้ใช้ sign in
  
* ในกรณีที่ request มาที่ route อื่น ๆ server จะทำการส่ง response เป็นหน้า `error.html` ([**ตัวอย่างผลลัพธ์ที่ 6**](#ตัวอย่างผลลัพธ์ที่-6))
  และมีการ log ใน terminal

---
## การส่งงาน
ส่ง (commit) ไฟล์ JS - `app.js` และไฟล์ html `sign-in.html`

---

## Expected Output


### ตัวอย่างผลลัพธ์ที่ 1 

[กลับไปที่โจทย์](#โจทย์)

เมื่อเริ่มรัน server ด้วยคำสั่ง `npm start` ควรมีข้อความ log ใน terminal ดังนี้
```
> <folder>@1.0.0 start
> nodemon app.js'

[nodemon] 3.1.14
[nodemon] to restart at any time, enter `rs`
[nodemon] watching path(s): *.*
[nodemon] watching extensions: js,mjs,cjs,json
[nodemon] starting `node app.js`
Server listening on port: 3030

```
<hr>

### ตัวอย่างผลลัพธ์ที่ 2

[กลับไปที่โจทย์](#โจทย์)

เมื่อผู้ใช้พิมพ์ `localhost:3030/` ผ่าน browser ซึ่งเป็นการส่ง **request** มาที่ **route** `/` server 
terminal ควรมีข้อความ log เป็น
```
Request at /
```
**และ** browser จะปรากฎข้อความเป็น **response** ดังนี้
<img width="775" alt="image" src="/expected_output/1.root.png">

<hr>

### ตัวอย่างผลลัพธ์ที่ 3 

[กลับไปที่โจทย์](#โจทย์)

เมื่อผู้ใช้พิมพ์ `localhost:3030/signin` ผ่าน browser ซึ่งเป็นการส่ง **request** มาที่ **route** `/signin`

terminal ควรมีข้อความ log เป็น
```
Request at /signin
Retrieve a form
```
**และ** browser จะมีผลลัพธ์เป็นหน้า `sign-in.html` เป็น **response** ดังนี้
<img width="775" alt="image" src="/expected_output/2.signin.png">
 
<hr>

### ตัวอย่างผลลัพธ์ที่ 4 

[กลับไปที่โจทย์](#โจทย์)

เมื่อผู้ใช้กรอกข้อมูลและกด "Submit" ฟอร์มจะถูกประมวลผล ที่ `/form-submit` ด้วย method `POST`
<img width="775" alt="image" src="/expected_output/3.formfill.png">

terminal ควรมีข้อความ log เป็น
```
Request at /form-submit
Form submitted by jidapa.kra@mahidol.edu at 1728453550390
```

โดยมีข้อความเป็นอีเมลและ timestamp

จากนั้น `redirect` ไปยัง route `/member` (**ตัวอย่างผลลัพธ์ที่ 5**)

<hr>

### ตัวอย่างผลลัพธ์ที่ 5 

[กลับไปที่โจทย์](#โจทย์)

เมื่อฟอร์มถูกประมวลผลที่ `/form-submit` เสร็จสิ้น จะถูก redirect มาที่ **route** `/member`
terminal ควรมีข้อความ log เป็น
```
Request at /member
```
และ browser จะปรากฎหน้า `success.html` ดังนี้
<img width="775" alt="image" src="/expected_output/4.success.png">

<hr>

### ตัวอย่างผลลัพธ์ที่ 6

[กลับไปที่โจทย์](#โจทย์)

เมื่อผู้ใช้ request มาที่ route อื่น ๆ ผ่าน browser (_ตัวอย่าง_ `localhost:3030/omg`)

terminal ควรมีข้อความ log เป็น

```
Request at /omg
404: Invalid accessed
```
และ browser จะปรากฎหน้า error.html ดังนี้
<img width="775" alt="image" src="/expected_output/5.error.png">

<hr>
