const path = require("path");
const express = require("express");

const app = express();

app.use(express.urlencoded({ extended: false }));

app.get ("/", (req, res) => {
    res.send("Hello World! in plain text");
    console.log("Request at /");
});

app.get("/signin", (req, res) => {
    console.log("Request at /signin");
    console.log("Retrieve a form");

    res.sendFile(
        path.join(__dirname, "html", "sign-in.html")
    );
});

app.post("/form-submit", (req, res) => {
    const email = req.body.email;
    const timestamp = Date.now();

    console.log("Request at /form-submit");
    console.log('Form submitted by ' + email+ ' at ' + timestamp);

    res.redirect("/member");
});

app.get("/member", (req, res) => {
    console.log("Request at /member");

    res.sendFile(
        path.join(__dirname, "html", "success.html")
    );

});

app.use((req, res) => {
    console.log("Request at " + req.path);
    console.log("404: Invalid accessed");

    res.status(404).sendFile(
        path.join(__dirname, "html", "error.html")
    );

})

app.listen(3030, () => {
    console.log("Server listening on port: 3030");
    
});